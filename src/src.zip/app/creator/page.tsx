import CreatorConsoleClient from "./ui/CreatorConsoleClient";

export const metadata = {
  title: "CREATOR CONSOLE // DESK",
};

export default function CreatorConsolePage() {
  return <CreatorConsoleClient />;
}

