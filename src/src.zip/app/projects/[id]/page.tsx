import { notFound } from "next/navigation";

export default function ProjectRecordPage() {
  // Demo route removed: the observer must be built from on-chain factory data,
  // so drafts and mock records are not addressable.
  notFound();
}

